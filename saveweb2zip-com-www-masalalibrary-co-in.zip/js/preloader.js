	rotate = 1;
	function hide_preloadAnim(){
		//$("#preloaderSpice").fadeOut(1000);
		setTimeout(function() {
      	// Do something after 5 seconds
		$("#preloaderSpice").fadeOut(1000);
		}, 500);
	}

	function hide_preloader() { //DOM
	rotate = 0;
	$("#preloader").fadeOut(1000);
	}
	
	$(document).ready(function(){
	
	// calculate height 
	var screen_ht = $(window).height();
	var preloader_ht = 80;
	var padding =(screen_ht/2)-preloader_ht;
	
	
	
	$('#jump').click(function() {
  		$('#hiddenNav').slideToggle('slow', function() {
    		// Animation complete.
  		});
	});
	
	
	$("#preloader").css("padding-top",padding+"px");
	
	// loading animation using script
		function anim(){ $("#preloader_image").animate({left:'-1400px'}, 5000,
		function(){ $("#preloader_image").animate({left:'0px'}, 2000 ); if(rotate==1){ anim();}  } );
		}
		anim();
	});